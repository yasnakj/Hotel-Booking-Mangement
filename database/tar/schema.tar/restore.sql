--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Hotel";
--
-- Name: Hotel; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Hotel" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "Hotel" OWNER TO postgres;

\connect "Hotel"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ensure_manager_exists(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.ensure_manager_exists() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (NEW.Role = 'Manager' AND NOT EXISTS (
        SELECT 1 FROM Employees WHERE HotelID = NEW.HotelID AND Role = 'Manager' AND EmployeeID != NEW.EmployeeID
    )) THEN
        RETURN NEW;
    ELSEIF (NEW.Role != 'Manager' AND NOT EXISTS (
        SELECT 1 FROM Employees WHERE HotelID = NEW.HotelID AND Role = 'Manager'
    )) THEN
        RAISE EXCEPTION 'Each hotel must have at least one manager.';
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.ensure_manager_exists() OWNER TO postgres;

--
-- Name: fn_prevent_hotel_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_prevent_hotel_deletion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Check for active bookings
  IF EXISTS (SELECT 1 FROM Bookings WHERE ID_Hotel = OLD.ID_Hotel) THEN
    RAISE EXCEPTION 'Cannot delete hotel with active bookings.';
  END IF;

  RETURN OLD;
END;
$$;


ALTER FUNCTION public.fn_prevent_hotel_deletion() OWNER TO postgres;

--
-- Name: fn_update_room_availability(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_update_room_availability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Assuming there's a column 'is_available' in the 'Room' table to update
  UPDATE Room
  SET is_available = FALSE
  WHERE Room_Number = NEW.Room_Number AND ID_Hotel = NEW.ID_Hotel;

  RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_update_room_availability() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: archive; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.archive (
    id_archive integer NOT NULL,
    number_bookings integer NOT NULL,
    number_rentings integer NOT NULL
);


ALTER TABLE public.archive OWNER TO postgres;

--
-- Name: archive_id_archive_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.archive_id_archive_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.archive_id_archive_seq OWNER TO postgres;

--
-- Name: archive_id_archive_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.archive_id_archive_seq OWNED BY public.archive.id_archive;


--
-- Name: hotel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hotel (
    id_hotel integer NOT NULL,
    chain_id integer,
    contact_emails character varying(255) NOT NULL,
    phone_number character varying(20),
    address character varying(255) NOT NULL,
    name character varying(255)
);


ALTER TABLE public.hotel OWNER TO postgres;

--
-- Name: room; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.room (
    room_number integer NOT NULL,
    id_hotel integer NOT NULL,
    room_price numeric(10,2) NOT NULL,
    amenities text,
    capacity character varying(50),
    problems text,
    extendable boolean NOT NULL,
    view character varying(50),
    is_available boolean DEFAULT true
);


ALTER TABLE public.room OWNER TO postgres;

--
-- Name: availableroomsperarea; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.availableroomsperarea AS
 SELECT SUBSTRING(h.address SIMILAR '%[^0-9,]%'::text ESCAPE ' '::text) AS area,
    count(*) AS available_rooms
   FROM (public.hotel h
     JOIN public.room r ON ((h.id_hotel = r.id_hotel)))
  WHERE (r.is_available = true)
  GROUP BY (SUBSTRING(h.address SIMILAR '%[^0-9,]%'::text ESCAPE ' '::text));


ALTER VIEW public.availableroomsperarea OWNER TO postgres;

--
-- Name: bookings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bookings (
    id_booking integer NOT NULL,
    id_hotel integer,
    room_number integer,
    start_date date NOT NULL,
    end_date date NOT NULL,
    special_request text
);


ALTER TABLE public.bookings OWNER TO postgres;

--
-- Name: bookings_id_booking_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bookings_id_booking_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bookings_id_booking_seq OWNER TO postgres;

--
-- Name: bookings_id_booking_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bookings_id_booking_seq OWNED BY public.bookings.id_booking;


--
-- Name: central_office; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.central_office (
    id_centoffice integer NOT NULL,
    address character varying(255) NOT NULL,
    chain_id integer
);


ALTER TABLE public.central_office OWNER TO postgres;

--
-- Name: central_office_id_centoffice_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.central_office_id_centoffice_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.central_office_id_centoffice_seq OWNER TO postgres;

--
-- Name: central_office_id_centoffice_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.central_office_id_centoffice_seq OWNED BY public.central_office.id_centoffice;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id_customer integer NOT NULL,
    name character varying(255) NOT NULL,
    registration_date date NOT NULL,
    address character varying(255) NOT NULL
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_customer_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_customer_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_id_customer_seq OWNER TO postgres;

--
-- Name: customer_id_customer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_customer_seq OWNED BY public.customer.id_customer;


--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    ssn_sin character varying(20) NOT NULL,
    name character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    salary numeric(10,2) NOT NULL,
    address character varying(255) NOT NULL,
    id_hotel integer
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: hotel_chain; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hotel_chain (
    chain_id integer NOT NULL,
    name character varying(255) NOT NULL,
    number_hotels integer NOT NULL,
    phone_number character varying(20),
    contact_emails character varying(255) NOT NULL
);


ALTER TABLE public.hotel_chain OWNER TO postgres;

--
-- Name: hotel_chain_chain_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hotel_chain_chain_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hotel_chain_chain_id_seq OWNER TO postgres;

--
-- Name: hotel_chain_chain_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hotel_chain_chain_id_seq OWNED BY public.hotel_chain.chain_id;


--
-- Name: hotel_id_hotel_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.hotel_id_hotel_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.hotel_id_hotel_seq OWNER TO postgres;

--
-- Name: hotel_id_hotel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.hotel_id_hotel_seq OWNED BY public.hotel.id_hotel;


--
-- Name: renting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.renting (
    id_renting integer NOT NULL,
    id_hotel integer,
    room_number integer,
    start_date date NOT NULL,
    end_date date NOT NULL
);


ALTER TABLE public.renting OWNER TO postgres;

--
-- Name: renting_id_renting_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.renting_id_renting_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.renting_id_renting_seq OWNER TO postgres;

--
-- Name: renting_id_renting_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.renting_id_renting_seq OWNED BY public.renting.id_renting;


--
-- Name: totalcapacityperhotel; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.totalcapacityperhotel AS
SELECT
    NULL::integer AS id_hotel,
    NULL::character varying(255) AS hotel_address,
    NULL::bigint AS total_capacity;


ALTER VIEW public.totalcapacityperhotel OWNER TO postgres;

--
-- Name: archive id_archive; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archive ALTER COLUMN id_archive SET DEFAULT nextval('public.archive_id_archive_seq'::regclass);


--
-- Name: bookings id_booking; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id_booking SET DEFAULT nextval('public.bookings_id_booking_seq'::regclass);


--
-- Name: central_office id_centoffice; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.central_office ALTER COLUMN id_centoffice SET DEFAULT nextval('public.central_office_id_centoffice_seq'::regclass);


--
-- Name: customer id_customer; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id_customer SET DEFAULT nextval('public.customer_id_customer_seq'::regclass);


--
-- Name: hotel id_hotel; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotel ALTER COLUMN id_hotel SET DEFAULT nextval('public.hotel_id_hotel_seq'::regclass);


--
-- Name: hotel_chain chain_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotel_chain ALTER COLUMN chain_id SET DEFAULT nextval('public.hotel_chain_chain_id_seq'::regclass);


--
-- Name: renting id_renting; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.renting ALTER COLUMN id_renting SET DEFAULT nextval('public.renting_id_renting_seq'::regclass);


--
-- Name: archive archive_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.archive
    ADD CONSTRAINT archive_pkey PRIMARY KEY (id_archive);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id_booking);


--
-- Name: central_office central_office_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.central_office
    ADD CONSTRAINT central_office_pkey PRIMARY KEY (id_centoffice);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id_customer);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (ssn_sin);


--
-- Name: hotel_chain hotel_chain_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotel_chain
    ADD CONSTRAINT hotel_chain_pkey PRIMARY KEY (chain_id);


--
-- Name: hotel hotel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotel
    ADD CONSTRAINT hotel_pkey PRIMARY KEY (id_hotel);


--
-- Name: renting renting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.renting
    ADD CONSTRAINT renting_pkey PRIMARY KEY (id_renting);


--
-- Name: room room_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_pkey PRIMARY KEY (room_number, id_hotel);


--
-- Name: idx_booking_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_booking_dates ON public.bookings USING btree (start_date, end_date);


--
-- Name: idx_hotel_chain_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_hotel_chain_id ON public.hotel USING btree (chain_id);


--
-- Name: idx_room_availability; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_room_availability ON public.room USING btree (is_available);


--
-- Name: idx_room_hotel_room_number; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_room_hotel_room_number ON public.room USING btree (id_hotel, room_number);


--
-- Name: idx_room_price; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_room_price ON public.room USING btree (room_price);


--
-- Name: totalcapacityperhotel _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.totalcapacityperhotel AS
 SELECT h.id_hotel,
    h.address AS hotel_address,
    sum((r.capacity)::integer) AS total_capacity
   FROM (public.hotel h
     JOIN public.room r ON ((h.id_hotel = r.id_hotel)))
  GROUP BY h.id_hotel;


--
-- Name: bookings trg_after_booking; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_after_booking AFTER INSERT ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.fn_update_room_availability();


--
-- Name: hotel trg_before_hotel_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_before_hotel_deletion BEFORE DELETE ON public.hotel FOR EACH ROW EXECUTE FUNCTION public.fn_prevent_hotel_deletion();


--
-- Name: bookings bookings_id_hotel_room_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_id_hotel_room_number_fkey FOREIGN KEY (id_hotel, room_number) REFERENCES public.room(id_hotel, room_number) ON DELETE CASCADE;


--
-- Name: central_office central_office_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.central_office
    ADD CONSTRAINT central_office_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.hotel_chain(chain_id) ON DELETE SET NULL;


--
-- Name: employee employee_id_hotel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_id_hotel_fkey FOREIGN KEY (id_hotel) REFERENCES public.hotel(id_hotel) ON DELETE SET NULL;


--
-- Name: hotel hotel_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hotel
    ADD CONSTRAINT hotel_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.hotel_chain(chain_id) ON DELETE CASCADE;


--
-- Name: renting renting_id_hotel_room_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.renting
    ADD CONSTRAINT renting_id_hotel_room_number_fkey FOREIGN KEY (id_hotel, room_number) REFERENCES public.room(id_hotel, room_number) ON DELETE CASCADE;


--
-- Name: room room_id_hotel_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.room
    ADD CONSTRAINT room_id_hotel_fkey FOREIGN KEY (id_hotel) REFERENCES public.hotel(id_hotel) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

