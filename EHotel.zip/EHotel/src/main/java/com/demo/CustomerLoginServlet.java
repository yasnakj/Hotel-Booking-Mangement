package com.demo;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class CustomerLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish a connection to the database
            con = DriverManager.getConnection("jdbc:mysql://localhost:5432/postgres", "postgres", "admin");

            // Create a SQL query to check if the customer exists with the given username and password
            String sql = "SELECT * FROM customers WHERE username = ? AND password = ?";
            stmt = con.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);

            // Execute the query
            rs = stmt.executeQuery();

            // Check if the user was found
            if (rs.next()) {
                // Authentication successful, redirect to customer dashboard
                response.sendRedirect("customerDashboard.jsp");
            } else {
                // Authentication failed, redirect back to login page with an error message
                response.sendRedirect("login.jsp?error=Invalid customer credentials");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database connection errors
            response.sendRedirect("login.jsp?error=Database connection error");
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

