package com.demo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookingService {
    private final Connection connection;

    public BookingService(Connection connection) {
        this.connection = connection;
    }

    public Booking getBookingById(int id) throws SQLException {
        String sql = "SELECT * FROM Bookings WHERE ID_Booking = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Booking(
                            resultSet.getInt("ID_Booking"),
                            resultSet.getInt("ID_Hotel"),
                            resultSet.getInt("Room_Number"),
                            resultSet.getDate("Start_Date"),
                            resultSet.getDate("End_Date"),
                            resultSet.getString("Special_Request"),
                            resultSet.getLong("column_7"),
                            resultSet.getInt("ID_Customer"),
                            resultSet.getInt("ID_Archive")
                    );
                }
            }
        }
        return null;
    }

    public List<Booking> getAllBookings() throws SQLException {
        List<Booking> bookings = new ArrayList<>();
        String sql = "SELECT * FROM Bookings";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Booking booking = new Booking(
                        resultSet.getInt("ID_Booking"),
                        resultSet.getInt("ID_Hotel"),
                        resultSet.getInt("Room_Number"),
                        resultSet.getDate("Start_Date"),
                        resultSet.getDate("End_Date"),
                        resultSet.getString("Special_Request"),
                        resultSet.getLong("column_7"),
                        resultSet.getInt("ID_Customer"),
                        resultSet.getInt("ID_Archive")
                );
                bookings.add(booking);
            }
        }
        return bookings;
    }

    public boolean insertBooking(Booking booking) throws SQLException {
        String sql = "INSERT INTO Bookings (ID_Hotel, Room_Number, Start_Date, End_Date, Special_Request, ID_Customer, ID_Archive) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, booking.getIdHotel());
            statement.setInt(2, booking.getRoomNumber());
            statement.setDate(3, new java.sql.Date(booking.getStartDate().getTime()));
            statement.setDate(4, new java.sql.Date(booking.getEndDate().getTime()));
            statement.setString(5, booking.getSpecialRequest());
            statement.setInt(6, booking.getIdCustomer());
            statement.setInt(7, booking.getIdArchive());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateBooking(Booking booking) throws SQLException {
        String sql = "UPDATE Bookings SET ID_Hotel = ?, Room_Number = ?, Start_Date = ?, End_Date = ?, Special_Request = ?, ID_Customer = ?, ID_Archive = ? WHERE ID_Booking = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, booking.getIdHotel());
            statement.setInt(2, booking.getRoomNumber());
            statement.setDate(3, new java.sql.Date(booking.getStartDate().getTime()));
            statement.setDate(4, new java.sql.Date(booking.getEndDate().getTime()));
            statement.setString(5, booking.getSpecialRequest());
            statement.setInt(6, booking.getIdCustomer());
            statement.setInt(7, booking.getIdArchive());
            statement.setInt(8, booking.getIdBooking());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteBooking(int id) throws SQLException {
        String sql = "DELETE FROM Bookings WHERE ID_Booking = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}
