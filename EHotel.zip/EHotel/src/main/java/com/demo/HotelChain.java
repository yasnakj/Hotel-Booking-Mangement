package com.demo;
public class HotelChain {
    private int chainId;
    private String name;
    private int numberOfHotels;
    private String phoneNumber;
    private String emailAddress;

    // Constructor
    public HotelChain(int chainId, String name, int numberOfHotels, String phoneNumber, String emailAddress) {
        this.chainId = chainId;
        this.name = name;
        this.numberOfHotels = numberOfHotels;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
    }

    // Getters and Setters
    public int getChainId() {
        return chainId;
    }

    public void setChainId(int chainId) {
        this.chainId = chainId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberOfHotels() {
        return numberOfHotels;
    }

    public void setNumberOfHotels(int numberOfHotels) {
        this.numberOfHotels = numberOfHotels;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    // toString method
    @Override
    public String toString() {
        return "HotelChain{" +
                "chainId=" + chainId +
                ", name='" + name + '\'' +
                ", numberOfHotels=" + numberOfHotels +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", emailAddress='" + emailAddress + '\'' +
                '}';
    }
}

