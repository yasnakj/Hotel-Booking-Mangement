package com.demo;

import java.util.Date;

public class Booking {
    private int bookingId;
    private int idHotel;
    private int roomNumber;
    private Date startDate;
    private Date endDate;
    private String specialRequest;
    private long column7; // Placeholder name, consider giving this a meaningful name
    private int idCustomer;
    private int idArchive;

    // Constructor
    public Booking(int bookingId, int idHotel, int roomNumber, Date startDate, Date endDate,
                   String specialRequest, long column7, int idCustomer, int idArchive) {
        this.bookingId = bookingId;
        this.idHotel = idHotel;
        this.roomNumber = roomNumber;
        this.startDate = startDate;
        this.endDate = endDate;
        this.specialRequest = specialRequest;
        this.column7 = column7;
        this.idCustomer = idCustomer;
        this.idArchive = idArchive;
    }

    public int getIdBooking() { return bookingId; }
    public int getIdHotel() { return idHotel; }
    public int getRoomNumber() { return roomNumber; }
    public Date getStartDate() { return startDate; }
    public Date getEndDate() { return endDate; }
    public String getSpecialRequest() { return specialRequest; }
    public long getColumn7() { return column7; } // Consider renaming this method
    public int getIdCustomer() { return idCustomer; }
    public int getIdArchive() { return idArchive; }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    // toString method
    @Override
    public String toString() {
        return "Booking{" +
                "bookingId=" + bookingId +
                ", idHotel=" + idHotel +
                ", roomNumber=" + roomNumber +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", specialRequest='" + specialRequest + '\'' +
                ", column7=" + column7 +
                ", idCustomer=" + idCustomer +
                ", idArchive=" + idArchive +
                '}';
    }
}