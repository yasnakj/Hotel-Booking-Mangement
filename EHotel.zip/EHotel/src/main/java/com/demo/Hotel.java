package com.demo;
public class Hotel {
    private int hotelId;
    private int chainId;
    private String email;
    private String phone;
    private String address;
    private String name;

    // Constructor
    public Hotel(int hotelId, int chainId, String email, String phone, String address, String name) {
        this.hotelId = hotelId;
        this.chainId = chainId;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.name = name;
    }

    // Getters and Setters
    public int getHotelId() {
        return this.hotelId;
    }
    public int getId() {
        return this.hotelId;
    }

    public void setHotelId(int hotelId) {
        this.hotelId = hotelId;
    }

    public int getChainId() {
        return chainId;
    }

    public void setChainId(int chainId) {
        this.chainId = chainId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // toString method
    @Override
    public String toString() {
        return "Hotel{" +
                "hotelId=" + hotelId +
                ", chainId=" + chainId +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
