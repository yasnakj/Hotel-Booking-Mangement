package com.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeService {

    private final Connection connection;

    public EmployeeService(Connection connection) {
        this.connection = connection;
    }

    public Employee getEmployeeById(int id) throws SQLException {
        String sql = "SELECT * FROM Employees WHERE EmployeeID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Employee(
                            resultSet.getString("SSN_SIN"),
                            resultSet.getString("FullName"),
                            resultSet.getString("Title"),
                            resultSet.getDouble("Salary"),
                            resultSet.getString("Address"),
                            resultSet.getInt("EmployeeID")
                    );
                }
            }
        }
        return null;
    }

    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> employees = new ArrayList<>();
        String sql = "SELECT * FROM Employees";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Employee employee = new Employee(
                        resultSet.getString("SSN_SIN"),
                        resultSet.getString("FullName"),
                        resultSet.getString("Title"),
                        resultSet.getDouble("Salary"),
                        resultSet.getString("Address"),
                        resultSet.getInt("EmployeeID")
                );
                employees.add(employee);
            }
        }
        return employees;
    }

    public boolean insertEmployee(Employee employee) throws SQLException {
        String sql = "INSERT INTO Employees (SSN_SIN, FullName, Title, Salary, Address) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, employee.getSsnSin());
            statement.setString(2, employee.getFullName());
            statement.setString(3, employee.getTitle());
            statement.setDouble(4, employee.getSalary());
            statement.setString(5, employee.getAddress());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateEmployee(Employee employee) throws SQLException {
        String sql = "UPDATE Employees SET SSN_SIN = ?, FullName = ?, Title = ?, Salary = ?, Address = ? WHERE EmployeeID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, employee.getSsnSin());
            statement.setString(2, employee.getFullName());
            statement.setString(3, employee.getTitle());
            statement.setDouble(4, employee.getSalary());
            statement.setString(5, employee.getAddress());
            statement.setInt(6, employee.getEmployeeId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM Employees WHERE EmployeeID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}