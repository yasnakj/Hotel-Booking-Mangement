package com.demo;

public class CentralOffice {
    private int idCentOffice;
    private String address;
    private int chainId;

    // Constructor
    public CentralOffice(int idCentOffice, String address, int chainId) {
        this.idCentOffice = idCentOffice;
        this.address = address;
        this.chainId = chainId;
    }
}
