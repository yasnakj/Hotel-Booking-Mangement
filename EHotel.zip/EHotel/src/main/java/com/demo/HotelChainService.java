package com.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HotelChainService {

    private final Connection connection;

    public HotelChainService(Connection connection) {
        this.connection = connection;
    }

    public HotelChain getHotelChainById(int id) throws SQLException {
        String sql = "SELECT * FROM HotelChains WHERE ChainID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new HotelChain(
                            resultSet.getInt("ChainID"),
                            resultSet.getString("Name"),
                            resultSet.getInt("NumberOfHotels"),
                            resultSet.getString("PhoneNumber"),
                            resultSet.getString("EmailAddress")
                    );
                }
            }
        }
        return null;
    }

    public List<HotelChain> getAllHotelChains() throws SQLException {
        List<HotelChain> hotelChains = new ArrayList<>();
        String sql = "SELECT * FROM HotelChains";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                HotelChain hotelChain = new HotelChain(
                        resultSet.getInt("ChainID"),
                        resultSet.getString("Name"),
                        resultSet.getInt("NumberOfHotels"),
                        resultSet.getString("PhoneNumber"),
                        resultSet.getString("EmailAddress")
                );
                hotelChains.add(hotelChain);
            }
        }
        return hotelChains;
    }

    public boolean insertHotelChain(HotelChain hotelChain) throws SQLException {
        String sql = "INSERT INTO HotelChains (Name, NumberOfHotels, PhoneNumber, EmailAddress) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, hotelChain.getName());
            statement.setInt(2, hotelChain.getNumberOfHotels());
            statement.setString(3, hotelChain.getPhoneNumber());
            statement.setString(4, hotelChain.getEmailAddress());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateHotelChain(HotelChain hotelChain) throws SQLException {
        String sql = "UPDATE HotelChains SET Name = ?, NumberOfHotels = ?, PhoneNumber = ?, EmailAddress = ? WHERE ChainID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, hotelChain.getName());
            statement.setInt(2, hotelChain.getNumberOfHotels());
            statement.setString(3, hotelChain.getPhoneNumber());
            statement.setString(4, hotelChain.getEmailAddress());
            statement.setInt(5, hotelChain.getChainId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteHotelChain(int id) throws SQLException {
        String sql = "DELETE FROM HotelChains WHERE ChainID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}
