package com.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomService {

    private final Connection connection;

    public RoomService(Connection connection) {
        this.connection = connection;
    }

    public Room getRoomById(int id) throws SQLException {
        String sql = "SELECT * FROM Rooms WHERE RoomID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Room(
                            resultSet.getInt("RoomID"),
                            resultSet.getInt("HotelID"),
                            resultSet.getDouble("Price"),
                            resultSet.getString("Amenities"),
                            resultSet.getString("Capacity"),
                            resultSet.getString("Problems"),
                            resultSet.getBoolean("IsAvailable"),
                            resultSet.getString("View"),
                            resultSet.getBoolean("CanBeExtended")
                    );
                }
            }
        }
        return null;
    }

    public List<Room> getAllRooms() throws SQLException {
        List<Room> rooms = new ArrayList<>();
        String sql = "SELECT * FROM Rooms";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Room room = new Room(
                        resultSet.getInt("RoomID"),
                        resultSet.getInt("HotelID"),
                        resultSet.getDouble("Price"),
                        resultSet.getString("Amenities"),
                        resultSet.getString("Capacity"),
                        resultSet.getString("Problems"),
                        resultSet.getBoolean("IsAvailable"),
                        resultSet.getString("View"),
                        resultSet.getBoolean("CanBeExtended")
                );
                rooms.add(room);
            }
        }
        return rooms;
    }

    public List<Room> getAvailableRooms(int hotelId) throws SQLException {
        List<Room> availableRooms = new ArrayList<>();
        String sql = "SELECT * FROM Rooms WHERE HotelID = ? AND IsAvailable = TRUE";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, hotelId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Room room = new Room(
                            resultSet.getInt("RoomID"),
                            resultSet.getInt("HotelID"),
                            resultSet.getDouble("Price"),
                            resultSet.getString("Amenities"),
                            resultSet.getString("Capacity"),
                            resultSet.getString("Problems"),
                            resultSet.getBoolean("IsAvailable"),
                            resultSet.getString("View"),
                            resultSet.getBoolean("CanBeExtended")
                    );
                    availableRooms.add(room);
                }
            }
        }
        return availableRooms;
    }

    public boolean updateRoomAvailability(int roomId, boolean isAvailable) throws SQLException {
        String sql = "UPDATE Rooms SET IsAvailable = ? WHERE RoomID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setBoolean(1, isAvailable);
            statement.setInt(2, roomId);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateRoom(Room room) throws SQLException {
        String sql = "UPDATE Rooms SET HotelID = ?, Price = ?, Amenities = ?, Capacity = ?, Problems = ?, View = ?, CanBeExtended = ? WHERE RoomID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, room.getHotelId());
            statement.setDouble(2, room.getPrice());
            statement.setString(3, room.getAmenities());
            statement.setString(4, room.getCapacity());
            statement.setString(5, room.getProblems());
            statement.setString(6, room.getView());
            statement.setBoolean(7, room.isCanBeExtended());
            statement.setInt(8, room.getRoomId());
            return statement.executeUpdate() > 0;
        }
    }
}