package com.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class CustomerService {

    private final Connection connection;

    public CustomerService(Connection connection) {
        this.connection = connection;
    }

    public Customer getCustomerById(int id) throws SQLException {
        String sql = "SELECT * FROM Customers WHERE CustomerID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Customer(
                            resultSet.getInt("CustomerID"),
                            resultSet.getString("FullName"),
                            resultSet.getString("Address"),
                            resultSet.getString("IDType"),
                            resultSet.getDate("RegistrationDate")
                    );
                }
            }
        }
        return null;
    }

    public List<Customer> getAllCustomers() throws SQLException {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM Customers";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Customer customer = new Customer(
                        resultSet.getInt("CustomerID"),
                        resultSet.getString("FullName"),
                        resultSet.getString("Address"),
                        resultSet.getString("IDType"),
                        resultSet.getDate("RegistrationDate")
                );
                customers.add(customer);
            }
        }
        return customers;
    }

    public boolean insertCustomer(Customer customer) throws SQLException {
        String sql = "INSERT INTO Customers (FullName, Address, IDType, RegistrationDate) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, customer.getFullName());
            statement.setString(2, customer.getAddress());
            statement.setString(3, customer.getIdType());
            statement.setDate(4, new java.sql.Date(customer.getRegistrationDate().getTime()));
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateCustomer(Customer customer) throws SQLException {
        String sql = "UPDATE Customers SET FullName = ?, Address = ?, IDType = ?, RegistrationDate = ? WHERE CustomerID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, customer.getFullName());
            statement.setString(2, customer.getAddress());
            statement.setString(3, customer.getIdType());
            statement.setDate(4, new java.sql.Date(customer.getRegistrationDate().getTime()));
            statement.setInt(5, customer.getCustomerId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteCustomer(int id) throws SQLException {
        String sql = "DELETE FROM Customers WHERE CustomerID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}