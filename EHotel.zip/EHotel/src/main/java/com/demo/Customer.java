package com.demo;

import java.util.Date;

public class Customer {
    private int customerId;
    private String fullName;
    private String address;
    private String idType;
    private Date registrationDate;

    // Constructor
    public Customer(int customerId, String fullName, String address, String idType, Date registrationDate) {
        this.customerId = customerId;
        this.fullName = fullName;
        this.address = address;
        this.idType = idType;
        this.registrationDate = registrationDate;
    }

    // Getters and Setters
    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    // toString method
    @Override
    public String toString() {
        return "Customer{" +
                "customerId=" + customerId +
                ", fullName='" + fullName + '\'' +
                ", address='" + address + '\'' +
                ", idType='" + idType + '\'' +
                ", registrationDate=" + registrationDate +
                '}';
    }
}
