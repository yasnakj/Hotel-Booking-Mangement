package com.demo;
public class Room {
    private int roomId;
    private int hotelId;
    private double price;
    private String amenities;
    private String capacity;
    private String problems;
    private boolean isAvailable;
    private String view;
    private boolean canBeExtended;

    // Constructor
    public Room(int roomId, int hotelId, double price, String amenities, String capacity, String problems, boolean isAvailable, String view, boolean canBeExtended) {
        this.roomId = roomId;
        this.hotelId = hotelId;
        this.price = price;
        this.amenities = amenities;
        this.capacity = capacity;
        this.problems = problems;
        this.isAvailable = isAvailable;
        this.view = view;
        this.canBeExtended = canBeExtended;
    }

    // Getters and Setters
    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public int getHotelId() {
        return hotelId;
    }

    public void setHotelId(int hotelId) {
        this.hotelId = hotelId;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAmenities() {
        return amenities;
    }

    public void setAmenities(String amenities) {
        this.amenities = amenities;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public String getProblems() {
        return problems;
    }

    public void setProblems(String problems) {
        this.problems = problems;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public boolean isCanBeExtended() {
        return canBeExtended;
    }

    public void setCanBeExtended(boolean canBeExtended) {
        this.canBeExtended = canBeExtended;
    }

    // toString method
    @Override
    public String toString() {
        return "Room{" +
                "roomId=" + roomId +
                ", hotelId=" + hotelId +
                ", price=" + price +
                ", amenities='" + amenities + '\'' +
                ", capacity='" + capacity + '\'' +
                ", problems='" + problems + '\'' +
                ", isAvailable=" + isAvailable +
                ", view='" + view + '\'' +
                ", canBeExtended=" + canBeExtended +
                '}';
    }
}