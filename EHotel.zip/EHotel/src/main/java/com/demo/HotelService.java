package com.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HotelService {

    private Connection connection;

    public HotelService(Connection connection) {
        this.connection = connection;
    }




    public Hotel getHotelById(int id) throws SQLException {
        String sql = "SELECT * FROM Hotels WHERE HotelID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Hotel(
                            resultSet.getInt("HotelID"),
                            resultSet.getInt("ChainID"),
                            resultSet.getString("Email"),
                            resultSet.getString("Phone"),
                            resultSet.getString("Address"),
                            resultSet.getString("Name")
                    );
                }
            }
        }
        return null;
    }

    public List<Hotel> getAllHotels() throws SQLException {
        List<Hotel> hotels = new ArrayList<>();
        String sql = "SELECT * FROM Hotels";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Hotel hotel = new Hotel(
                        resultSet.getInt("HotelID"),
                        resultSet.getInt("ChainID"),
                        resultSet.getString("Email"),
                        resultSet.getString("Phone"),
                        resultSet.getString("Address"),
                        resultSet.getString("Name")
                );
                hotels.add(hotel);
            }
        }
        return hotels;
    }

    public boolean insertHotel(Hotel hotel) throws SQLException {
        String sql = "INSERT INTO Hotels (ChainID, Email, Phone, Address, Name) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, hotel.getChainId());
            statement.setString(2, hotel.getEmail());
            statement.setString(3, hotel.getPhone());
            statement.setString(4, hotel.getAddress());
            statement.setString(5, hotel.getName());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateHotel(Hotel hotel) throws SQLException {
        String sql = "UPDATE Hotels SET ChainID = ?, Email = ?, Phone = ?, Address = ?, Name = ? WHERE HotelID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, hotel.getChainId());
            statement.setString(2, hotel.getEmail());
            statement.setString(3, hotel.getPhone());
            statement.setString(4, hotel.getAddress());
            statement.setString(5, hotel.getName());
            statement.setInt(6, hotel.getHotelId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteHotel(int id) throws SQLException {
        String sql = "DELETE FROM Hotels WHERE HotelID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}