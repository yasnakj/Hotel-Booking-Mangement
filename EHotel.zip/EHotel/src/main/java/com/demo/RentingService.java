package com.demo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RentingService {

    private final Connection connection;

    public RentingService(Connection connection) {
        this.connection = connection;
    }

    public Renting getRentingById(int id) throws SQLException {
        String sql = "SELECT * FROM Rentings WHERE RentingID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return new Renting(
                            resultSet.getInt("RentingID"),
                            resultSet.getInt("CustomerID"),
                            resultSet.getInt("RoomID"),
                            resultSet.getDate("StartDate"),
                            resultSet.getDate("EndDate"),
                            resultSet.getDouble("TotalCost")
                    );
                }
            }
        }
        return null;
    }

    public List<Renting> getAllRentings() throws SQLException {
        List<Renting> rentings = new ArrayList<>();
        String sql = "SELECT * FROM Rentings";
        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Renting renting = new Renting(
                        resultSet.getInt("RentingID"),
                        resultSet.getInt("CustomerID"),
                        resultSet.getInt("RoomID"),
                        resultSet.getDate("StartDate"),
                        resultSet.getDate("EndDate"),
                        resultSet.getDouble("TotalCost")
                );
                rentings.add(renting);
            }
        }
        return rentings;
    }

    public boolean insertRenting(Renting renting) throws SQLException {
        String sql = "INSERT INTO Rentings (CustomerID, RoomID, StartDate, EndDate, TotalCost) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, renting.getCustomerId());
            statement.setInt(2, renting.getRoomId());
            statement.setDate(3, new java.sql.Date(renting.getStartDate().getTime()));
            statement.setDate(4, new java.sql.Date(renting.getEndDate().getTime()));
            statement.setDouble(5, renting.getTotalCost());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean updateRenting(Renting renting) throws SQLException {
        String sql = "UPDATE Rentings SET CustomerID = ?, RoomID = ?, StartDate = ?, EndDate = ?, TotalCost = ? WHERE RentingID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, renting.getCustomerId());
            statement.setInt(2, renting.getRoomId());
            statement.setDate(3, new java.sql.Date(renting.getStartDate().getTime()));
            statement.setDate(4, new java.sql.Date(renting.getEndDate().getTime()));
            statement.setDouble(5, renting.getTotalCost());
            statement.setInt(6, renting.getRentingId());
            return statement.executeUpdate() > 0;
        }
    }

    public boolean deleteRenting(int id) throws SQLException {
        String sql = "DELETE FROM Rentings WHERE RentingID = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            return statement.executeUpdate() > 0;
        }
    }
}