package com.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "HotelListServlet", urlPatterns = {"/HotelListServlet"})
public class HotelListServlet extends HttpServlet {
    private HotelService hotelService;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            Connection connection = DatabaseUtils.getConnection(); // This line might throw SQLException
            hotelService = new HotelService(connection); // Passing the connection to the constructor
        } catch (SQLException e) {
            // Handle exception: log it, wrap it in a ServletException, etc.
            throw new ServletException("Database connection error", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<Hotel> hotels = hotelService.getAllHotels(); // Fetch the list of hotels from the database
            request.setAttribute("hotels", hotels); // Set the list of hotels as a request attribute
            request.getRequestDispatcher("/index.jsp").forward(request, response); // Forward the request to the JSP page
        } catch (SQLException e) {
            throw new ServletException("Error retrieving hotels", e);
        }
    }
}