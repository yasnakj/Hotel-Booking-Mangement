package com.demo;

public class Employee {
    private String ssnSin;
    private String fullName;
    private String title;
    private double salary;
    private String address;
    private int employeeId;

    // Constructor
    public Employee(String ssnSin, String fullName, String title, double salary, String address, int employeeId) {
        this.ssnSin = ssnSin;
        this.fullName = fullName;
        this.title = title;
        this.salary = salary;
        this.address = address;
        this.employeeId = employeeId;
    }

    // Getters and Setters
    public int getEmployeeId() {
        return employeeId;
    }
    public double getSalary() {
        return salary;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSsnSin() {
        return ssnSin;
    }

    public void setSsnSin(String ssnSin) {
        this.ssnSin = ssnSin;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // toString method
    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", fullName='" + fullName + '\'' +
                ", title='" + title + '\'' +
                ", salary=" + salary +
                ", address='" + address + '\'' +
                '}';
    }
}

