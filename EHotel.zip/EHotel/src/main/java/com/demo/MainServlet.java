package com.demo;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
    private BookingService bookingService;

    public void init() {
        // Here, set up your database connection and instantiate the BookingService
        // For example: this.bookingService = new BookingService(DBConnection.getConnection());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getServletPath();

        try {
            switch (action) {
                case "/new":
                    insertBooking(request, response);
                    break;
                case "/delete":
                    deleteBooking(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateBooking(request, response);
                    break;
                default:
                    listBookings(request, response);
                    break;
            }
        } catch (SQLException | ParseException ex) {
            throw new ServletException(ex);
        }
    }

    private void listBookings(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        // Code to retrieve a list of bookings and set it as a request attribute
        // Forward to JSP for display
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        // Code to find a specific booking and set it as a request attribute
        // Forward to an edit JSP view
    }

    private void insertBooking(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ParseException {
        // Code to create a booking
        response.sendRedirect("listBookings");
    }

    private void updateBooking(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ParseException {
        // Code to update a booking
        response.sendRedirect("listBookings");
    }

    private void deleteBooking(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
        // Code to delete a booking
        response.sendRedirect("listBookings");
    }

    // Add doGet if you need to handle any GET requests
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void destroy() {
        // Close database connections, etc. if necessary.
    }
}